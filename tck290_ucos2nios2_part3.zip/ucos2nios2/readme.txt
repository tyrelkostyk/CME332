Readme - Hello MicroC/OS-II Hello Software Example

Hello_uosii is a simple hello world program running MicroC/OS-II.  The
purpose of the design is to be a very simple application that just
demonstrates MicroC/OS-II running on NIOS II.  The design doesn't account
for issues such as checking system call return codes. etc.

The MicroC/OS-II RTOS is not open-source software and can be used free of charge 
for non-commercial purposes and academic projects only. 
Use of the code is subject to the terms of an end-user license agreement, 
please see the license files included in the BSP project.
